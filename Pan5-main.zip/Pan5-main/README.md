# MAKABAGONG AI-DEA: TEKNOLOHIYA BILANG INSTRUMENTO SA PAGLIKHA NG SINING

## Deskripsyon

Ang **Makabagong AI-Dea** ay isang website na inilaan upang talakayin ang papel ng teknolohiya, lalo na ang artificial intelligence (AI), bilang instrumento sa paglikha ng sining. Layunin ng website na ito na magbigay ng impormasyon at mapagkukunan tungkol sa mga epekto ng teknolohiya sa sining.

## Privacy at Seguridad

Sa website na ito, pinapahalagahan namin ang iyong privacy. Narito ang mga pangunahing aspeto tungkol sa aming patakaran sa privacy:

- **Data Collection:** Hindi kami nangangalap ng anumang personal na impormasyon mula sa mga bisita sa website na ito.
- **Cookies:** Ang website ay maaaring gumamit ng cookies para sa mga layuning pang-analitika. Hindi ito naglalaman ng anumang personal na impormasyon.
- **Third-Party Links:** Ang website ay maaaring maglaman ng mga link sa mga third-party na site. Hindi kami responsable para sa mga patakaran sa privacy ng mga site na ito.

## Paano Gamitin

1. **Bisitahin ang aming website:** [[Link to website](https://arleykun.github.io/Pan5)]
2. **Tuklasin ang mga nilalaman at impormasyon tungkol sa AI sa sining.**

## Kontak

Para sa anumang katanungan o mungkahi, mangyaring makipag-ugnayan sa amin sa [abaromin0427@gmail.com].

## Lisensya

Ang nilalaman ng website na ito ay protektado ng copyright. Ang anumang pag-gamit ng mga materyal mula sa site na ito ay dapat na may pahintulot.

Salamat sa pagbisita sa **Makabagong AI-Dea**!
